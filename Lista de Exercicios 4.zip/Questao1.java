import java.util.Scanner;

class Questao1{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
	
		float base=0;
		float expoente;
		float resultado;
		System.out.println("Digite a base");
		base=scan.nextFloat();
		System.out.println("Digite o expoente");
		expoente=scan.nextFloat();
		resultado=base;
		if(expoente<0){
			base=1/base;
			resultado=base;
		
		}
		
		for(int i=1; i<Math.abs(expoente); i++){// 2 3
		
				resultado*=base;
		
			
		}
		if(expoente==0){
			resultado=1;
		}
		
		
		System.out.printf("O resultado e: %.3f", resultado);
		
	}
	
	
	
}