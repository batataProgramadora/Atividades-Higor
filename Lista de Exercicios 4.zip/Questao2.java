import java.util.Scanner;

class Questao1{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		int num1;
		int num2;
		int operacao=1;
		int resultado=0;
		while(operacao!=0){
			
			System.out.println("Selecione uma das opcoes: \n\n 1- Soma \n 2- Subtracao \n 3- Multiplicacao \n 4- Divisao \n 0- Sair \n");
			operacao=scan.nextInt();
			if(operacao==0){
				continue;
			}
			System.out.println("Digite o primeiro numero");
			num1=scan.nextInt();
			System.out.println("Digite o segundo numero");
			num2=scan.nextInt();
			switch(operacao){
				case 1:
					resultado=num1+num2;
					break;
				case 2:
					resultado=num1-num2;
					break;
				case 3:
					resultado=num1*num2;
					break;
				case 4:
					resultado=num1/num2;
					break;
					
			}
			System.out.printf("O resultado e: %d\n", resultado);
			System.out.println("==============================================");
			
		}	
		
	}
	
	
	
	
}